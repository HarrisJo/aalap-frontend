import { BrowserRouter, Routes, Route } from 'react-router-dom'
import LandingPage from './pages/LandingPage'
import AuthPage from './pages/AuthPage'
import HomeFeed from "./pages/HomeFeed.tsx";
import ThreadDetail from "./pages/ThreadDetail.tsx";
import ProfilePage from "./pages/ProfilePage.tsx";
import PublicProfilePage from "./pages/PublicProfilePage.tsx";

function App() {
    return (
        <BrowserRouter>
            <Routes>
                <Route path="/"            element={<LandingPage />} />
                <Route path="/auth"        element={<AuthPage />} />
                <Route path="/home"        element={<HomeFeed />} />
                <Route path="/threads/:id" element={<ThreadDetail />} />
                <Route path="/profile"     element={<ProfilePage />} />
                <Route path="/users/:id"   element={<PublicProfilePage />} />
            </Routes>
        </BrowserRouter>
    )
}

export default App